package com.pubgsensitivitypro

import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

private val Bg = Color(0xFF090A0D)
private val Panel = Color(0xFF17191F)
private val Gold = Color(0xFFFFC857)
private val White = Color(0xFFF4F4F5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Panel, primary = Color(0xFFE53935), secondary = Gold)) {
                App()
            }
        }
    }
}

private val scopes = listOf("TPP No Scope", "FPP No Scope", "Red Dot / Holo", "2x Scope", "3x Scope", "4x Scope", "6x Scope", "8x Scope")
private val categories = listOf("Camera", "ADS", "Gyroscope", "ADS Gyroscope")
private val playStyles = listOf("Full Gyroscope", "No Gyroscope", "2 Finger", "3 Finger", "4 Finger Claw", "5 Finger Claw", "6 Finger Claw", "Rush Aggressive", "Spray Stabil", "Sniper Player")
private val templateNames = listOf("iPhone Style", "Android Low End", "Android Mid Range", "Android High End", "Anti Recoil", "Full Gyroscope", "No Gyroscope", "M416 Spray", "AKM", "Sniper")

@Composable
private fun App() {
    var page by remember { mutableStateOf("Dashboard") }
    var device by remember { mutableStateOf("${Build.MANUFACTURER} ${Build.MODEL}") }
    var style by remember { mutableStateOf(playStyles[0]) }
    var profileName by remember { mutableStateOf("My Profile") }
    var savedProfiles by remember { mutableStateOf(listOf<String>()) }
    var values by remember { mutableStateOf(categories.associateWith { scopes.associateWith { 100f } }) }
    val clipboard = LocalClipboardManager.current
    val allText = categories.joinToString("\n\n") { category ->
        "$category\n" + scopes.joinToString("\n") { scope -> "$scope: ${values[category]?.get(scope)?.roundToInt() ?: 100}" }
    }

    Scaffold(containerColor = Bg, bottomBar = {
        NavigationBar(containerColor = Panel) {
            listOf("Dashboard", "Generator", "Templates", "Profiles").forEach { destination ->
                NavigationBarItem(selected = page == destination, onClick = { page = destination },
                    icon = { Text(when (destination) { "Dashboard" -> "⌂"; "Generator" -> "⚙"; "Templates" -> "▤"; else -> "♙" }) },
                    label = { Text(destination) })
            }
        }
    }) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Text("PUBG SENSITIVITY PRO", color = Gold, fontWeight = FontWeight.Black, fontSize = 22.sp)
                Text("SENSITIVITY LAB • OFFLINE", color = White.copy(alpha = .65f), fontSize = 11.sp)
            }
            when (page) {
                "Dashboard" -> {
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("DEVICE PROFILE", color = Gold, fontSize = 12.sp)
                                OutlinedTextField(value = device, onValueChange = { device = it }, label = { Text("Merek / tipe HP") }, modifier = Modifier.fillMaxWidth())
                                Text("Deteksi Android: ${Build.MANUFACTURER} ${Build.MODEL}", color = White.copy(alpha = .6f), fontSize = 12.sp)
                            }
                        }
                    }
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            StatCard("4", "Kategori", Modifier.weight(1f))
                            StatCard("32", "Nilai", Modifier.weight(1f))
                            StatCard("Offline", "Mode", Modifier.weight(1f))
                        }
                    }
                    categories.forEach { category ->
                        item { SensitivityCard(category, values[category] ?: emptyMap()) { scope, value ->
                            values = values.toMutableMap().also { it[category] = (it[category] ?: emptyMap()).toMutableMap().also { map -> map[scope] = value } }
                        } }
                    }
                    item { Button(onClick = { clipboard.setText(AnnotatedString(allText)) }, modifier = Modifier.fillMaxWidth()) { Text("COPY ALL") } }
                    item { OutlinedButton(onClick = { values = categories.associateWith { scopes.associateWith { 100f } } }, modifier = Modifier.fillMaxWidth()) { Text("RESET SETTINGS") } }
                }
                "Generator" -> {
                    item { Text("Automatic recommendation", color = Gold, fontWeight = FontWeight.Bold, fontSize = 20.sp) }
                    item { Text("Rekomendasi adalah titik awal untuk diuji dan disesuaikan, bukan jaminan cocok untuk semua pemain.", color = White.copy(alpha = .75f)) }
                    item { OutlinedTextField(value = device, onValueChange = { device = it }, label = { Text("Tipe HP") }, modifier = Modifier.fillMaxWidth()) }
                    item { OutlinedTextField(value = style, onValueChange = { style = it }, label = { Text("Gaya bermain") }, modifier = Modifier.fillMaxWidth()) }
                    item { Button(onClick = {
                        val base = when (style) { "Rush Aggressive" -> 135f; "Sniper Player" -> 70f; "No Gyroscope" -> 100f; else -> 110f }
                        values = categories.associateWith { category ->
                            scopes.mapIndexed { index, scope ->
                                scope to if (category.contains("Gyroscope") && style == "No Gyroscope") 0f else (base - index * 7).coerceIn(0f, 300f)
                            }.toMap()
                        }
                        page = "Dashboard"
                    }, modifier = Modifier.fillMaxWidth()) { Text("GENERATE RECOMMENDATION") } }
                    item { Text("Gaya yang tersedia: ${playStyles.joinToString(", ")}", color = White.copy(alpha = .6f), fontSize = 12.sp) }
                }
                "Templates" -> {
                    item { Text("Template library", color = Gold, fontWeight = FontWeight.Bold, fontSize = 20.sp) }
                    items(templateNames) { name ->
                        Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(name, color = White, modifier = Modifier.weight(1f))
                                TextButton(onClick = { page = "Dashboard" }) { Text("Use") }
                                TextButton(onClick = { savedProfiles = savedProfiles + name }) { Text("Save") }
                            }
                        }
                    }
                }
                else -> {
                    item { Text("Saved profiles", color = Gold, fontWeight = FontWeight.Bold, fontSize = 20.sp) }
                    item { OutlinedTextField(value = profileName, onValueChange = { profileName = it }, label = { Text("Nama profil HP") }, modifier = Modifier.fillMaxWidth()) }
                    item { Button(onClick = { savedProfiles = savedProfiles + profileName }, modifier = Modifier.fillMaxWidth()) { Text("SAVE PROFILE") } }
                    items(savedProfiles) { Text("• $it", color = White) }
                    item { Text("Profil disimpan sementara selama sesi aplikasi pada versi awal ini.", color = White.copy(alpha = .6f), fontSize = 12.sp) }
                }
            }
        }
    }
}

@Composable
private fun StatCard(value: String, label: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = Panel)) {
        Column(Modifier.padding(12.dp)) {
            Text(value, color = Gold, fontWeight = FontWeight.Bold)
            Text(label, color = White.copy(alpha = .6f), fontSize = 11.sp)
        }
    }
}

@Composable
private fun SensitivityCard(title: String, current: Map<String, Float>, onChange: (String, Float) -> Unit) {
    var expanded by remember { mutableStateOf(title == "Camera") }
    Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Row {
                Text(title, color = Gold, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                TextButton(onClick = { expanded = !expanded }) { Text(if (expanded) "Hide" else "Edit") }
            }
            if (expanded) scopes.forEach { scope ->
                val value = current[scope] ?: 100f
                Text("$scope • ${value.roundToInt()}", color = White, fontSize = 13.sp)
                Slider(value = value, valueRange = 0f..300f, onValueChange = { onChange(scope, it) })
            }
        }
    }
}
